INSERT INTO korisnici (id, ime, prezime, email)
VALUES ('1', 'Marko', 'Marković', 'marko@example.com');
INSERT INTO korisnici (id, ime, prezime, email)
VALUES ('2', 'Ana', 'Anić', 'ana@example.com');
